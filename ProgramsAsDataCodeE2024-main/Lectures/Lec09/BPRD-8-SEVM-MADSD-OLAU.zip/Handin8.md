# Handin 8



## Exercise 9.1

see virtual/Selsort/Selsort.il 
and virtual/Selsort/Selsort.jvmbytecode


## Exercise 9.2
see virtual/StringConcatSpeed/KvantitativDatam�lingStringConcat.png 
and virtual/StringConcatSpeed/KvantitativDatam�lingOtherApp.png

(We produced some code to track with perfmon. See TestProj)



## Exercise 9.3 (We chose to do 9.2)



