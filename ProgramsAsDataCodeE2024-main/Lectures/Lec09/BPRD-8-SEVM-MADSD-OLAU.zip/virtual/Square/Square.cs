// 
// sestoft@itu.dk * 2009-10-21

using System;

class Square {
  public static void Main(String[] args) {
    Console.WriteLine(Sqr(6.2));
  }

  public static double Sqr(double x) {
    return x * x;
  }
}
